# AVIA OpenBadges Infrastructure

Este repositorio contiene los archivos base para emitir insignias verificables usando el estándar OpenBadges 2.0

## Contenido
- `public/issuer.json`: Perfil del emisor AVIA Studio
- `public/revoked-badges.json`: Lista vacía de revocaciones
- `public/assets/insignia.png`: Imagen de la insignia
- `vercel.json`: Configuración para despliegue en Vercel

## Despliegue rápido

1. Haz fork de este repositorio.
2. Ve a [Vercel](https://vercel.com/import/git) e importa el proyecto desde GitHub.
3. Asegúrate de que los archivos estén en la carpeta `public/` para ser accesibles públicamente.

### URLs esperadas

- https://<tu-subdominio>.vercel.app/issuer.json
- https://<tu-subdominio>.vercel.app/assets/insignia.png
- https://<tu-subdominio>.vercel.app/revoked-badges.json
